:- discontiguous p1/1.
p1(a).
p2(a).
p1(b).
%%%%%%%%%%%%%%%%
p1(a).
p2(a).
p1(b).

